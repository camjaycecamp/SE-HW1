// import joi, express, fs, bodyparser
const Joi = require('joi');
const express = require ('express');
const fs = require ('fs');
const res = require('express/lib/response');
const app = express();
var bodyParser = require('body-parser');
// set var for the array of tweets from the JSON
var tweetArray = [];
// use folder for attaching an image to the webpage
app.use("/images",  express.static(__dirname + '/images'));
// bodyparser initialization for push and put requests
app.use(express.json());
app.use(bodyParser.json());


/*   ______________
    |              |
    |  FUNCTIONS   |
    |______________|
*/

// file system module for reading in JSON file and parsing into an array of (tweet) objects
fs.readFile('./favs.json', 'utf-8', (err, data) =>
{
    console.log('favs.json parsed!');
    var obj = JSON.parse(data);
    var i = 0;

    obj.forEach(tweet => 
    {
        tweetArray[i] = tweet;
        i++;
    });
});

// helper function for rendering tweets on the webpage
// hybrid of html and js logic for simpler rendering
function makeTweetsPost(tweet) 
{
    return "<div><h2>" 
        + "</h2><h4> Tweet ID: "
        + tweet.id
        + "</h4><p>" 
        + tweet.text
        + "</p><footer>" 
        + tweet.created_at 
        + "</footer></div>";
}

// helper function for rendering users on the webpage
// hybrid of html and js logic for simpler rendering
function makeUsersPost(tweet) 
{
    return "<div><h1>" 
        + tweet.user.name 
        + " (@" + tweet.user.screen_name
        + ") </h1><h4>User ID: " 
        + tweet.user.id
}



/*   ______________
    |              |
    |  OPERATIONS  |
    |______________|
*/

// get response for rendering home page via index.html and res.sendFile
app.get('/', (req, res) => 
{
    res.sendFile(__dirname + '\\index.html');
    // res.send('<div>' + posts + '</div>');
});

// get response for rendering tweets page for task 1: get all tweets
app.get('/tweets', (req, res) => 
{
    var posts = '';

    tweetArray.forEach(tweet => 
    {
        posts += makeTweetsPost(tweet);
    });

    res.send('<div>' + posts + '</div>');
    
});

// get response for rendering users page for task 2: get all user IDs
app.get('/users', (req, res) => 
{
    var posts = '';

    tweetArray.forEach(tweet => 
    {
        posts += makeUsersPost(tweet);
    });

    res.send('<div>' + posts + '</div>');
    
});

// get response for rendering tweets subpages for task 3: finding individual tweets given ID
app.get(`/tweets/:id`, (req, res) => 
{
    var id = req.params.id;

    tweetArray.forEach(tweet => 
        {
            if(tweet.id == id) 
            {
                res.send(tweet.user.name 
                + " (@" + tweet.user.screen_name
                + ") \nTweet ID: "
                + tweet.id
                + "\n\n" 
                + tweet.text
                + "\n\n" 
                + tweet.created_at);
                return;
            }
        });
});

// app delete response for task 4: deleting a tweet given ID
app.delete('/tweets/:id', (req, res) => 
{
    var id = req.params.id;
    var BreakException = {};

    try 
    {
        tweetArray.forEach(tweet => 
            {
                if(tweet.id == id) 
                {
                    console.log(tweetArray.indexOf(tweet));
                    tweetArray.splice(tweetArray.indexOf(tweet), 1);
                    throw BreakException;
                }
            });
    }
    catch (e)
    {
        if (e !== BreakException) throw e;
    }
});

// app post response for task 5: creating new tweets given text and ID
app.post('/tweets/:id', (req, res) => 
{
    var id = req.body.id;
    var text = req.body.text;

    var tweet = 
    {
        id: id,
        text: text,
        created_at: 'Feb 2022'
    };
    tweetArray.push(tweet);
});

// app put request for task 6: updating an existing screen name given real name and new screen name
app.put('/users/', (req, res) => 
{
    var realName = req.body.realName;
    var newScreenName = req.body.newScreenName;
    var BreakException = {};

    try 
    {
        tweetArray.forEach(tweet => 
            {
                if(tweet.user.name == realName) 
                {
                    console.log(tweetArray.indexOf(tweet));
                    tweet.user.screen_name = newScreenName;
                    
                    throw BreakException;
                }
            });
    }
    catch (e)
    {
        if (e !== BreakException) throw e;
    }
});

// general server listener for port 3000
// allows the RESTful API to function on that port
app.listen(3000, () => console.log('Listening on port 3000...'));